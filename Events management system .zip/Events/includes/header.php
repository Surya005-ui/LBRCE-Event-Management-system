<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Body Styling */
        body {
            background-color: #0a192f; /* Dark Blue Theme */
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Navbar Container */
        .nav-container {
            padding-top: 30px;
            padding-left: 50px;
            padding-right: 50px;
        }

        /* Floating Navbar */
        nav {
            background: linear-gradient(135deg, #1167b1, #0a3d62); /* Blue Gradient */
            padding: 15px 30px;
            border-radius: 15px;
            display: flex;
            gap: 15px;
            box-shadow: 0px 10px 20px rgba(17, 81, 115, 0.5);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
            backdrop-filter: blur(8px);
        }

        /* Hover & Active Effects */
        nav:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0px 15px 30px rgba(17, 81, 115, 0.7);
        }

        /* Nav Links */
        nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            padding: 8px 15px;
            position: relative;
            transition: color 0.3s ease-in-out;
        }

        /* Underline Effect */
        nav a::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: -3px; /* Adjust the position */
            width: 0;
            height: 2px;
            background: white;
            transition: width 0.3s ease-in-out, background 0.3s ease-in-out;
        }

        /* Hover Effects */
        nav a:hover {
            color: #ffcc00; /* Text color change on hover */
        }

        nav a:hover::after {
            width: 100%;
            background: #ffcc00; /* Underline color change on hover */
        }

        /* Active Link Styling */
        nav a.active {
            color: #ff5733 !important; /* Different color for active link */
        }

        nav a.active::after {
            width: 100%;
            background: #ff5733; /* Underline matches active link color */
        }

    </style>
</head>
<body>

    <div class="nav-container">
        <nav>
            <a href="index.php" class="nav-link" onclick="setActive(this)">Home</a>
            <a href="upcoming.php" class="nav-link" onclick="setActive(this)">Upcoming Events</a>
            <a href="past.php" class="nav-link" onclick="setActive(this)">Past Events</a>
            <a href="auth/login.php" class="nav-link" onclick="setActive(this)">Add Event</a>
        </nav>
    </div>

    <script>
        // Function to set the active link
        function setActive(link) {
            document.querySelectorAll(".nav-link").forEach(item => item.classList.remove("active"));
            link.classList.add("active");
        }

        // Preserve active link on page reload
        document.addEventListener("DOMContentLoaded", function () {
            const currentPath = window.location.pathname;
            document.querySelectorAll(".nav-link").forEach(link => {
                if (link.getAttribute("href") === currentPath) {
                    link.classList.add("active");
                }
            });
        });
    </script>

</body>
</html>
