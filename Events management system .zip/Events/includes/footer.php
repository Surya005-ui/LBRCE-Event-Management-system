<style>

footer {
    text-align: center;
    margin-top: 20px;
    background-color: #333;
}

footer p {
    color: white;
}
</style>

<footer>
    <p>&copy; 2025 Event Management System</p>
</footer>
</body>
</html>