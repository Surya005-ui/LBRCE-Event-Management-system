<?php
include 'config/db.php';


// Auto-update status
$updateQuery = "UPDATE events SET status = 'Completed' WHERE date < CURDATE() AND status != 'Completed'";
mysqli_query($conn, $updateQuery);

// Handle AJAX Filter Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['is_filter'])) {
    $department = $_POST['department'] ?? '';
    $type = $_POST['type'] ?? '';
    $category = $_POST['category'] ?? '';
    $date = $_POST['date'] ?? '';

    $where = "status='Completed'";
    if ($department) $where .= " AND department='" . mysqli_real_escape_string($conn, $department) . "'";
    if ($type) $where .= " AND event_type='" . mysqli_real_escape_string($conn, $type) . "'";
    if ($category) $where .= " AND event_category='" . mysqli_real_escape_string($conn, $category) . "'";
    if ($date) $where .= " AND date='" . mysqli_real_escape_string($conn, $date) . "'";

    $query = "SELECT * FROM events WHERE $where ORDER BY department, date ASC";
    $result = mysqli_query($conn, $query);

    $grouped = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $grouped[$row['department']][] = $row;
    }

    if (empty($grouped)) {
        echo "<p style='text-align:center;color:#ccc;'>No completed events found for selected filters.</p>";
        exit;
    }

    foreach ($grouped as $dept => $events) {
        echo "<div class='department-section'>";
        echo "<h2>$dept</h2><div class='cards'>";
        foreach ($events as $event) {
            echo "<div class='card'>
                <h3>{$event['title']}</h3>
                <p><strong>Type:</strong> {$event['event_type']}</p>
                <p><strong>Category:</strong> {$event['event_category']}</p>
                <p><strong>Date:</strong> " . date('d-m-Y', strtotime($event['date'])) . "</p>
                <div class='card-buttons'>
                    <button onclick='openModal({$event['id']})'>View Details</button>
                </div>
            </div>";
        }
        echo "</div></div>";
    }
    exit;
}

// Filter Dropdown Options
$departments = mysqli_query($conn, "SELECT DISTINCT department FROM events WHERE status='Completed'");
$eventTypes = mysqli_query($conn, "SELECT DISTINCT event_type FROM events WHERE status='Completed'");
$categories = mysqli_query($conn, "SELECT DISTINCT event_category FROM events WHERE status='Completed'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Completed Events</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #0a192f;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #00e5ff;
            margin-bottom: 40px;
        }
        .filter-box {
            background: #112240;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 40px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            box-shadow: 0 0 10px rgba(0,255,255,0.2);
        }
        .filter-box select,
        .filter-box input[type="date"] {
            padding: 10px;
            border-radius: 8px;
            border: none;
            background-color: #1c2948;
            color: white;
        }
        .filter-box button {
            background-color: #1eb2ff;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .filter-box button:hover {
            background-color: #00e5ff;
            transform: scale(1.05);
        }
        .department-section {
            margin-bottom: 60px;
        }
        .department-section h2 {
            color: #00ccff;
            border-bottom: 2px solid #00ccff;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        .cards {
            margin-left: 30px;
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            gap: 20px;
        }
        .card {
            position: relative;
            width: 300px;
            padding: 20px;
            border-radius: 20px;
            background: linear-gradient(135deg, #122c5e, #193b73);
            box-shadow: 0px 5px 15px rgba(0, 119, 255, 0.5);
            overflow: hidden;
            transition: transform 0.5s ease-in-out, box-shadow 0.4s;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0px 10px 30px rgba(0, 119, 255, 0.7);
        }
        .card:hover::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 10px;
            height: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            animation: ripple 1s infinite ease-out;
        }
        @keyframes ripple {
            0% {
                width: 5px;
                height: 5px;
                opacity: 0.6;
            }
            100% {
                width: 250px;
                height: 250px;
                opacity: 0;
            }
        }
        .card-buttons {
            margin-top: 15px;
            display:flex;
            justify-content: center;
            align-items: center;
        }
        .card-buttons button {
            background: #1eb2ff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            width: 90%;
            color: white;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .card-buttons button:hover {
            background: #0056b3;
            transform: scale(1.05);
        }
        .modal-overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .modal-content {
            background: #0a192f;
            width: 85%;
            padding: 20px 60px;
            border-radius: 10px;
            max-height: 70vh;
            overflow-y: auto;
            position: relative;
            animation: fadeIn 0.4s ease-in-out;
        }
        .modal-content::-webkit-scrollbar {
            width: 8px;
        }
        .modal-content::-webkit-scrollbar-track {
            background: #0a192f;
        }
        .modal-content::-webkit-scrollbar-thumb {
            background-color: #1eb2ff;
            border-radius: 10px;
            border: 2px solid #0a192f;
        }
        .close-modal {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 48px;
            font-weight: bold;
            color: #fff;
            cursor: pointer;
        }
        .close-modal:hover {
            color: #ff0000;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<?php include 'includes/header.php';?>
<h1>Completed Events</h1>
<div class="filter-box">
    <form id="filterForm">
        <select name="department">
            <option value="">All Departments</option>
            <?php while ($dept = mysqli_fetch_assoc($departments)) echo "<option value='{$dept['department']}'>{$dept['department']}</option>"; ?>
        </select>
        <select name="type">
            <option value="">All Event Types</option>
            <?php while ($type = mysqli_fetch_assoc($eventTypes)) echo "<option value='{$type['event_type']}'>{$type['event_type']}</option>"; ?>
        </select>
        <select name="category">
            <option value="">All Categories</option>
            <?php while ($cat = mysqli_fetch_assoc($categories)) echo "<option value='{$cat['event_category']}'>{$cat['event_category']}</option>"; ?>
        </select>
        <input type="date" name="date">
        <button type="submit">Apply Filter</button>
        <button type="button" id="resetBtn">Reset</button>
    </form>
</div>

<div id="eventsContainer">
    <!-- AJAX-loaded content will appear here -->
</div>

<!-- Modal -->
<div id="eventModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <span class="close-modal" onclick="closeModal()">×</span>
        <div id="modalBody">Loading...</div>
    </div>
</div>

<script>
    $(document).ready(function () {
        function loadEvents() {
            $('#eventsContainer').html("<p style='text-align:center;'>Loading events...</p>");
            $.ajax({
                url: '',
                type: 'POST',
                data: $('#filterForm').serialize() + '&is_filter=1',
                success: function (response) {
                    $('#eventsContainer').html(response);
                }
            });
        }

        loadEvents();

        $('#filterForm').on('submit', function (e) {
            e.preventDefault();
            loadEvents();
        });

        $('#resetBtn').on('click', function () {
            $('#filterForm')[0].reset();
            loadEvents();
        });
    });

    function openModal(id) {
        document.getElementById('eventModal').style.display = 'flex';
        document.getElementById('modalBody').innerHTML = 'Loading...';
        fetch(`student/view_past_event.php?event_id=${id}`)
            .then(res => res.text())
            .then(data => document.getElementById('modalBody').innerHTML = data)
            .catch(() => document.getElementById('modalBody').innerHTML = "<p>Failed to load event details.</p>");
    }

    function closeModal() {
        document.getElementById('eventModal').style.display = 'none';
    }

    window.onclick = function (e) {
        if (e.target == document.getElementById('eventModal')) closeModal();
    }
</script>
</body>
</html>
