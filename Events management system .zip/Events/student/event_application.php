<?php
session_start();
include '../config/db.php';

// Check if event_id is set
if (!isset($_SESSION['event_id']) || !isset($_SESSION['event_code_valid'])) {
    header("Location: register_event.php");
    exit();
}

// Get the event ID
$event_id = $_SESSION['event_id'];

// Fetch the latest registered user details
$query = "SELECT * FROM registrations WHERE event_id = '$event_id' ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $user_name = $user['student_name'];
    $user_email = $user['student_email'];
    $team_name = $user['team_name'];
    $phone_number = $user['phone_number'];
    $student1 = $user['student1'];
    $student2 = $user['student2'];
    $student3 = $user['student3'];
    $student4 = $user['student4'];
    $student5 = $user['student5'];

    // Email Details
    $to = $user_email;
    $subject = "Event Registration Successful - Waiting for Confirmation";
    $from = "y.n.v.n.kumar@gmail.com";
    
    // Email Headers
    $headers = "From: $from\r\n";
    $headers .= "Reply-To: $from\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    // Email Body
    $email_body = "<html><body>";
    $email_body .= "<h2>Event Registration Successful</h2>";
    $email_body .= "<p>Dear <strong>$user_name</strong>,</p>";
    $email_body .= "<p>Your application for the event has been received. Please wait for further confirmation regarding selection.</p>";
    $email_body .= "<h3>Application Details:</h3>";
    $email_body .= "<p><strong>Team Name:</strong> $team_name</p>";
    $email_body .= "<p><strong>Phone Number:</strong> $phone_number</p>";
    $email_body .= "<p><strong>Team Members:</strong><br>";
    $email_body .= "1. $student1<br>";
    $email_body .= "2. $student2<br>";
    $email_body .= "3. $student3<br>";
    $email_body .= "4. $student4<br>";
    $email_body .= "5. $student5</p>";
    $email_body .= "<p>We will notify you soon about your application status.</p>";
    $email_body .= "<p>Best Regards,<br>Event Management Team</p>";
    $email_body .= "</body></html>";

    // Send Email
    if (mail($to, $subject, $email_body, $headers)) {
        echo "<p style='color:green;'>Confirmation email sent successfully to $user_email.</p>";
    } else {
        echo "<p style='color:red;'>Failed to send confirmation email.</p>";
    }

} else {
    echo "<p style='color:red;'>No registration found for this event.</p>";
}

// Unset the session after sending email
unset($_SESSION['event_id']);
unset($_SESSION['event_code_valid']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Application Sent</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 50px;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
            display: inline-block;
            text-align: left;
        }
        h2 { color: #1a73e8; }
        p { font-size: 16px; }
    </style>
</head>
<body>

<div class="container">
    <h2>Application Submitted Successfully</h2>
    <p>Thank you, <strong><?= htmlspecialchars($user_name) ?></strong>. Your event registration has been submitted successfully.</p>
    <p>An email confirmation has been sent to: <strong><?= htmlspecialchars($user_email) ?></strong>.</p>
    <p>Please wait for further updates regarding your application status.</p>
    <a href="../index.php">Back to Home</a>
</div>

</body>
</html>
