<?php
session_start();
include '../config/db.php';

$event_id = $_GET['event_id'] ?? null;
$error_message = "";
$success_message = "";

if ($event_id) {
    $query = "SELECT * FROM events WHERE id = '$event_id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
        $event_code_db = $event['event_code'];
        $event_name = $event['title'];
        $event_description = $event['description'];
        $event_date = $event['date'];
        $event_location = $event['venue'];
        $event_time = $event['time'];
        $status = $event['status'];
        $event_rules = $event['event_rules'];
        $department = $event['department'];
        $registration_fee = $event['registration_fee'];
        $event_type = $event['event_type'];
        $event_category = $event['event_category'];


        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['validate_event'])) {
            $entered_code = $_POST['event_code'];
            if ($entered_code === $event_code_db) {
                $_SESSION['event_code_valid'] = true;
                $_SESSION['event_id'] = $event_id;
            } else {
                $error_message = "Invalid Event Code! Please enter the correct code.";
            }
        }
    } else {
        $error_message = "Event not found!";
    }
} else {
    $error_message = "Invalid Event!";
}

$event_code_valid = $_SESSION['event_code_valid'] ?? false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_event'])) {
    if ($event_code_valid) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $team_name = $_POST['team_name'];
        $student1 = $_POST['student1'];
        $student2 = $_POST['student2'];
        $student3 = $_POST['student3'];
        $student4 = $_POST['student4'];
        $student5 = $_POST['student5'];
        $phone_number = $_POST['phone_number'];

        $insert_query = "INSERT INTO registrations 
            (event_id, student_name, student_email, team_name, student1, student2, student3, student4, student5, phone_number) 
            VALUES ('$event_id', '$name', '$email', '$team_name', '$student1','$student2','$student3','$student4','$student5','$phone_number')";

        if ($conn->query($insert_query)) {
            // Send Confirmation Email
            $subject = "Application is sent successfully";
            $message = "
                <html>
                <head>
                    <title>Event Registration Successful</title>
                </head>
                <body>
                    <h2>Thank you for registering, $name!</h2>
                    <p>You have successfully registered for the event.</p>
                    <p><strong>Team Name:</strong> $team_name</p>
                    <p><strong>Team Members:</strong> $student1, $student2, $student3, $student4, $student5</p>
                    <p>We look forward to seeing you at the event!</p>
                </body>
                </html>
            ";
            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8\r\n";
            $headers .= "From: lbrce_events@lbrce.ac.in\r\n";

            if (mail($email, $subject, $message, $headers)) {
                $success_message = "Registration successful! A confirmation email has been sent to $email.";
            } else {
                $error_message = "Registration successful, but email sending failed.";
            }

            $_SESSION['event_code_valid'] = false;
            $_SESSION['event_id'] = null;
            header('Location: ../index.php');
            exit();
        } else {
            $error_message = "Error: " . $conn->error;
        }
    } else {
        $error_message = "Event code validation failed! Please enter the event code again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background-color: #e8f0fe;
        }
        a { text-decoration: none; }
        .header {
            background: linear-gradient(to right, #0A192F, #0A192F);
            padding: 60px 20px;
            color: #fff;
            border-bottom-left-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        .header-content {
            border-radius: 9px;
            max-width: 720px;
            margin: 0 auto;
            background:#041f51;  
            padding-top:30px;
            padding-left: 40px;  
            padding-bottom:30px;
        }

        .header-content h1{
            text-transform:uppercase;
            text-align:center;
            font-size:18px;
        }

        .header-content p{
            color: #fff;
            font-size:12px;
        }        
        .header-content p.dept{
            color: #01579B;
            font-weight:800;
            font-size:16px;
            text-shadow: 1px 0px 1px rgb(24, 106, 169);
            letter-spacing: 1.5px;
        }        
        .header-content p strong{
            color: #90CAF9;
        }        

        .form-container {
            max-width: 720px;
            background-color: #fff;
            margin: 0 auto 40px;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: -50px; /* slight overlap for perfect join */
            position: relative;
            z-index: 2;
        }


        .form-title { font-size: 28px; margin-bottom: 6px; color: #202124; }
        .form-description { font-size: 14px; color: #5f6368; margin-bottom: 20px; }
        .message {
            padding: 12px;
            font-size: 14px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        .success { background-color: #e6f4ea; color: #137333; }
        .error { background-color: #fce8e6; color: #d93025; }
        .question { margin-bottom: 28px; }
        .question label {
            font-size: 16px;
            color: #202124;
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="email"], input[type="number"] {
            width: 100%;
            font-size: 16px;
            padding: 12px;
            border: none;
            border-bottom: 1px solid #dadce0;
            background-color: transparent;
        }
        input:focus { outline: none; border-bottom: 2px solid #1a73e8; }
        .submit-btn {
            background-color: #1a73e8;
            color: #fff;
            padding: 12px 24px;
            font-size: 14px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .submit-btn:hover { background-color: #1558b0; }

        .disc_scrolebar {
            height: 100px;
            overflow-y: auto;
            padding-right: 10px;
            scrollbar-width: thin;
            scrollbar-color: #0288d1 transparent;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 8px;
            padding: 10px;
            font-size:10px;
            margin-right:5%;
            text-align:justify;
        }

        .disc_scrolebar::-webkit-scrollbar {
            width: 8px;
        }

        .disc_scrolebar::-webkit-scrollbar-thumb {
            background: #0288d1;
            border-radius: 10px;
        }
            
    </style>
</head>
<body>

<div class="header">
    <?php if ($event_id && isset($event_name)): ?>
        <div class="header-content">
            <h1><?= htmlspecialchars($event_name) ?></h1>
            <div><p class="dept">Organizing <?= htmlspecialchars($department) ?> Department</p></div>
            <div><p><strong>Date:</strong> <?= htmlspecialchars($event_date) ?> 
            <br><strong>Venue:</strong> <?= htmlspecialchars($event_location) ?>  
            <br><strong>Time:</strong> <?= htmlspecialchars($event_time) ?></p></div>
            <div><p><strong>Event Status: </strong><?= htmlspecialchars($status) ?></p></div>
            <div><p><strong>Description:</strong><br><div class="disc_scrolebar">
                 <?= nl2br(htmlspecialchars($event['description'])) ?>
            </div></p></div>
            <div><p><strong>Event Rules:</strong><br><?= nl2br(htmlspecialchars($event['event_rules'])) ?></p></div>
            <div><p><strong>Registration Fee:</strong> <?= htmlspecialchars($registration_fee) ?></p></div>
            <div><p><strong>Event Type: </strong><?= htmlspecialchars($event_type) ?></p></div>
            <div><p><strong>Event Category: </strong><?= htmlspecialchars($event_category) ?></p></div>
        </div>
    <?php endif; ?>
</div>


<div class="form-container">
    <h1 class="form-title"><?= $event_code_valid ? "Register for Event" : "Enter Event Code" ?></h1>
    <p class="form-description"><?= $event_code_valid ? "Fill the details below to complete registration." : "Please enter the event code provided by the organizer." ?></p>

    <?php if ($success_message): ?>
        <div class="message success"><?= $success_message ?></div>
    <?php elseif ($error_message): ?>
        <div class="message error"><?= $error_message ?></div>
    <?php endif; ?>

    <?php if (!$event_code_valid): ?>
        <form method="post">
            <div class="question">
                <label for="event_code">Event Code</label>
                <input type="text" name="event_code" id="event_code" required>
            </div>
            <button type="submit" name="validate_event" class="submit-btn">Validate</button>
            <a href="../index.php" class="submit-btn" style="margin-left: 10px; background-color: #ccc; color: #000;">Back</a>
        </form>
    <?php else: ?>
        <form method="post">
            <input type="hidden" name="event_id" value="<?= htmlspecialchars($event_id) ?>">
            <div class="question"><label>Your Name</label><input type="text" name="name" required></div>
            <div class="question"><label>Your Email</label><input type="email" name="email" required></div>
            <div class="question"><label>Your Phone Number</label><input type="number" name="phone_number" required></div>
            <div class="question"><label>Team Name</label><input type="text" name="team_name" required></div>
            <div class="question"><label>Team Member 1</label><input type="text" name="student1" required></div>
            <div class="question"><label>Team Member 2</label><input type="text" name="student2" required></div>
            <div class="question"><label>Team Member 3</label><input type="text" name="student3"></div>
            <div class="question"><label>Team Member 4</label><input type="text" name="student4"></div>
            <div class="question"><label>Team Member 5</label><input type="text" name="student5"></div>
            <button type="submit" name="register_event" class="submit-btn">Register</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
