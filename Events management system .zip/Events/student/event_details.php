<?php
include '../config/db.php';
if (!isset($_GET['event_id'])) exit("No event selected.");
$id = intval($_GET['event_id']);
$event = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM events WHERE id = $id"));
if (!$event) exit("Event not found.");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Event Details</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #0a192f 0%, #1c2b4d 100%);
      color: #fff;
      overflow-x: hidden;
    }

    .event-detail-wrapper {
      padding: 40px;
      max-width: 1000px;
      margin: 60px auto;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 20px;
      backdrop-filter: blur(12px);
      box-shadow: 0 0 30px rgba(0, 136, 255, 0.3), 0 0 80px rgba(0, 136, 255, 0.2);
      transition: all 0.3s ease-in-out;
      animation: fadeIn 1.2s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .event-detail-wrapper:hover {
      box-shadow: 0 0 40px rgba(0, 136, 255, 0.6), 0 0 100px rgba(0, 136, 255, 0.4);
      transform: scale(1.01);
    }

    h1 {
      font-size: 2.5rem;
      font-weight: 800;
      margin-bottom: 10px;
      color: #00bcd4;
      text-shadow: 0 0 10px rgba(0,188,212,0.4);
    }

    .subheading {
      font-size: 1.1rem;
      color: #4dd0e1;
      margin-bottom: 25px;
      font-weight: 600;
    }

    img {
      width: 100%;
      max-height: 350px;
      object-fit: cover;
      border-radius: 12px;
      margin-bottom: 25px;
      transition: transform 0.5s ease;
    }

    img:hover {
      transform: scale(1.02);
    }

    .event-content {
      display: flex;
      gap: 30px;
      margin-top: 30px;
      flex-wrap: wrap;
    }

    ul {
      list-style: none;
      padding: 0;
    }

    ul li {
      font-size: 14px;
      line-height: 1.8;
      margin-bottom: 15px;
      position: relative;
      padding-left: 10px;
      animation: slideIn 0.7s ease forwards;
    }

    ul li strong {
      color: #90caf9;
      font-size: 13px;
    }

    @keyframes slideIn {
      from { opacity: 0; transform: translateX(-20px); }
      to { opacity: 1; transform: translateX(0); }
    }

    .disc_scrolebar {
      height: 100px;
      overflow-y: auto;
      padding-right: 10px;
      scrollbar-width: thin;
      scrollbar-color: #0288d1 transparent;
      background: rgba(255,255,255,0.02);
      border-radius: 8px;
      text-align:justify;
      padding: 10px;
    }

    .disc_scrolebar::-webkit-scrollbar {
      width: 8px;
    }

    .disc_scrolebar::-webkit-scrollbar-thumb {
      background: #0288d1;
      border-radius: 10px;
    }

    .event-details {
      flex: 1 1 100%;
    }

    .eve_details {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 15px;
      margin-bottom: 20px;
    }

    .eve_div {
      background: rgba(255, 255, 255, 0.04);
      padding: 10px 15px;
      border-radius: 10px;
      flex: 1 1 45%;
      transition: all 0.3s ease;
    }

    .eve_div:hover {
      background: rgba(255, 255, 255, 0.08);
      transform: scale(1.02);
    }

    .event-buttons {
      display: flex;
      gap: 20px;
      margin-top: 30px;
      justify-content: center;
    }

    .event-buttons a,
    .event-buttons .close-model {
      background: linear-gradient(to right, #0288d1, #26c6da);
      color: white;
      text-decoration: none;
      padding: 12px 24px;
      border-radius: 10px;
      font-weight: 600;
      box-shadow: 0 4px 15px rgba(0,188,212,0.4);
      transition: 0.3s ease-in-out;
      cursor: pointer;
    }

    .event-buttons a:hover,
    .event-buttons .close-model:hover {
      transform: translateY(-3px) scale(1.05);
      background: linear-gradient(to right, #00acc1, #00e5ff);
    }

    @media (max-width: 768px) {
      .event-content {
        flex-direction: column;
      }

      .eve_details {
        flex-direction: column;
      }

      .eve_div {
        width: 100%;
      }

      .event-buttons {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>

<div class="event-detail-wrapper">
  <?php if (!empty($event['event_image'])): 
    $imgPath = htmlspecialchars('uploads/' . basename($event['event_image']));
  ?>
    <img src="<?= $imgPath ?>" alt="Event Image">
  <?php endif; ?>

  <h1><?= htmlspecialchars($event['title']) ?></h1>
  <p class="subheading"><?= htmlspecialchars($event['department']) ?> Department</p>

  <div class="event-content">
    <div class="event-details">
      <ul>
        <li>
          <div class="eve_details">
            <div class="eve_div"><strong>Date:</strong> <?= htmlspecialchars($event['date']) ?></div>
            <div class="eve_div"><strong>Time:</strong> <?= htmlspecialchars($event['time']) ?></div>
            <div class="eve_div"><strong>Venue:</strong> <?= htmlspecialchars($event['venue']) ?></div>
            <div class="eve_div"><strong>Event Category:</strong> <?= htmlspecialchars($event['event_category']) ?></div>
            <div class="eve_div"><strong>Event Type:</strong> <?= htmlspecialchars($event['event_type']) ?></div>
          </div>
        </li>
        <li><strong>Description:</strong><br><br>
          <div class="disc_scrolebar">
            <?= nl2br(htmlspecialchars($event['description'])) ?>
          </div>
        </li>
        <li><strong>Rules:</strong><br><?= nl2br(htmlspecialchars($event['event_rules'])) ?></li>
        <li><strong>Registration Fee:</strong> <?= htmlspecialchars($event['registration_fee']) ?></li>
      </ul>
    </div>
  </div>

  <div class="event-buttons">
    <a href="student/register_event.php?event_id=<?= $event['id'] ?>">Register</a>
    <div class="close-model" onclick="closeModal()">Close</div>
  </div>
</div>

<script>
  function closeModal() {
    document.querySelector('.event-detail-wrapper').style.opacity = 0;
    setTimeout(() => {
      document.querySelector('.event-detail-wrapper').style.display = 'none';
    }, 300);
  }
</script>
</body>
</html>
