<?php
include '../config/db.php';

if (!isset($_GET['event_id'])) {
    echo "<p>Invalid request.</p>";
    exit;
}
$event_id = intval($_GET['event_id']);

// Fetch event details
$eventQuery = mysqli_query($conn, "SELECT * FROM events WHERE id = $event_id");
if (!$eventQuery || mysqli_num_rows($eventQuery) == 0) {
    echo "<p>Event not found.</p>";
    exit;
}
$event = mysqli_fetch_assoc($eventQuery);

// Fetch images grouped by type
$imagesByType = [];
$imgQuery = mysqli_query($conn, "SELECT image_url, type FROM images WHERE event_id = $event_id");
while ($img = mysqli_fetch_assoc($imgQuery)) {
    $imagesByType[$img['type']][] = base64_encode($img['image_url']);
}
?>

<div style="color: white;">
    <h2 style="color: #00e5ff;"><?php echo htmlspecialchars($event['title']); ?></h2>
    <p><strong>Department:</strong> <?php echo htmlspecialchars($event['department']); ?></p>
    <p><strong>Type:</strong> <?php echo htmlspecialchars($event['event_type']); ?></p>
    <p><strong>Category:</strong> <?php echo htmlspecialchars($event['event_category']); ?></p>
    <p><strong>Date:</strong> <?php echo date('d-m-Y', strtotime($event['date'])); ?></p>
    <p><strong>Registration Fee:</strong> ₹<?php echo htmlspecialchars($event['registration_fee']); ?></p>
    <p><strong>Event Code:</strong> <?php echo htmlspecialchars($event['event_code']); ?></p>
    <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
    <p><strong>Rules:</strong><br><?php echo nl2br(htmlspecialchars($event['event_rules'])); ?></p>
 <hr>
    <?php if (!empty($imagesByType)): ?>
        <?php foreach ($imagesByType as $type => $images): ?>
            <h3 style="margin-top: 25px; color: #1eb2ff;"><?php echo ucfirst(str_replace('_', ' ', $type)); ?> Images</h3>
            <div style="display: flex; flex-wrap: wrap; gap: 15px; margin-top: 10px;">
                <?php foreach ($images as $img): ?>
                    <img src="data:image/jpeg;base64,<?php echo $img; ?>" style="width: 200px; height: auto; border-radius: 12px; box-shadow: 0 0 12px rgba(0, 229, 255, 0.5);" alt="Event Image">
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color: #ccc; margin-top: 20px;">No images available for this event.</p>
    <?php endif; ?>

    <div style="text-align:center; margin-top:30px;">
        <button onclick="closeModal()" style="background:#ff4081; padding:10px 20px; border:none; border-radius:8px; color:white; cursor:pointer;">Close</button>
    </div>
</div>
