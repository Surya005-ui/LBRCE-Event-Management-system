<?php
// DB connection
include '../config/db.php';
$event_id = $_GET['event_id'] ?? '';
if (!$event_id) die("Event ID missing.");

// Fetch event
$stmt = $conn->prepare("SELECT * FROM events WHERE id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

// Fetch dropdown options
function fetchOptions($conn, $column) {
  $result = $conn->query("SELECT DISTINCT $column FROM events");
  $options = [];
  while ($row = $result->fetch_assoc()) $options[] = $row[$column];
  return $options;
}
$types = fetchOptions($conn, 'event_type');
$cats = fetchOptions($conn, 'event_category');
$depts = fetchOptions($conn, 'department');
$statuses = ['upcoming', 'completed'];
$img_types = ['event_images', 'winner_1', 'winner_2', 'winner_3'];

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];

    if ($status === 'upcoming') {
      $title = $_POST['title'];
      $desc = $_POST['description'];
      $date = $_POST['date'];
      $time = $_POST['time'];
      $venue = $_POST['venue'];
      $ecode = $_POST['event_code'];
      $rules = $_POST['event_rules'];
      $dept = $_POST['department'];
      $fee = $_POST['registration_fee'];
      $type = $_POST['event_type'];
      $cat = $_POST['event_category'];
      $img = !empty($_FILES['event_image']['tmp_name']) ? file_get_contents($_FILES['event_image']['tmp_name']) : null;
  
      // Prepare and bind (use a real variable for the blob)
      $stmt = $conn->prepare("UPDATE events SET title=?, description=?, date=?, time=?, venue=?, status=?, event_code=?, event_image=?, event_rules=?, department=?, registration_fee=?, event_type=?, event_category=? WHERE id=?");
  
      // You must bind a variable by reference for 'b' type
      $stmt->bind_param("sssssssbsssssi", $title, $desc, $date, $time, $venue, $status, $ecode, $img, $rules, $dept, $fee, $type, $cat, $event_id);
  
      // Send long data for the blob parameter (8th param, index 7)
      if ($img !== null) {
          $stmt->send_long_data(7, $img);
      }
  
      $stmt->execute();
  
      echo "<script>alert('" . ($stmt->affected_rows > 0 ? "✅ Upcoming event successfully updated." : "⚠️ No changes made to the upcoming event.") . "');</script>";
  }
   else {
        $any_uploaded = false;

        if (!empty($_FILES['event_images']['tmp_name'])) {
            foreach ($_FILES['event_images']['tmp_name'] as $k => $tmp) {
                if (!is_uploaded_file($tmp)) continue;

                $img_data = file_get_contents($tmp);
                $img_type = $_POST['image_types'][$k] ?? 'event_images';

                if (in_array($img_type, ['winner_1', 'winner_2', 'winner_3'])) {
                    $del = $conn->prepare("DELETE FROM images WHERE event_id = ? AND type = ?");
                    $del->bind_param("is", $event_id, $img_type);
                    $del->execute();
                }

                $stmt = $conn->prepare("INSERT INTO images (event_id, image_url, type) VALUES (?, ?, ?)");
                $null = NULL;
                $stmt->bind_param("ibs", $event_id, $null, $img_type);
                $stmt->send_long_data(1, $img_data);
                $stmt->execute();

                if ($stmt->affected_rows > 0) $any_uploaded = true;
            }
        }

        echo "<script>alert('" . ($any_uploaded ? "✅ Images successfully uploaded." : "⚠️ No images were uploaded or modified.") . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Event</title>
  <style>
    body {
      background: linear-gradient(to bottom right, #001933, #003366);
      font-family: 'Segoe UI', sans-serif;
      color: #fff;
      padding: 40px;
    }
    form {
      max-width: 900px;
      margin: auto;
      padding: 40px;
      background-color: rgba(0, 0, 0, 0.2);
      border: 2px solid #00bfff88;
      border-radius: 20px;
      box-shadow: 0 0 30px #00bfff66;
    }
    .form-group {
      margin-bottom: 25px;
    }
    label {
      display: block;
      margin-bottom: 8px;
      color: #00bfff;
      font-weight: bold;
    }
    input, select, textarea {
      width: 100%;
      padding: 12px 16px;
      margin-top: 6px;
      border: 2px solid #00bfff;
      border-radius: 10px;
      background-color: #001933;
      color: #ffffff;
      font-size: 15px;
    }
    input[type="date"]::-webkit-calendar-picker-indicator,
    input[type="time"]::-webkit-calendar-picker-indicator {
      filter: invert(1) sepia(1) saturate(5) hue-rotate(180deg);
    }
    input:focus, select:focus, textarea:focus {
      border-color: #00bfff;
      box-shadow: 0 0 10px #00bfff;
      outline: none;
    }
    .button-group {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      margin-top: 30px;
    }
    .button {
      flex: 1;
      padding: 14px;
      font-size: 16px;
      border-radius: 30px;
      background: #00bfff;
      color: #001933;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: 0.3s ease;
    }
    .button:hover {
      background: #0099dd;
      box-shadow: 0 0 15px #00bfff;
    }
    .form-block {
      border: 2px dashed #00bfff;
      padding: 20px;
      margin-bottom: 30px;
      border-radius: 20px;
      background: rgba(0, 0, 0, 0.3);
    }
    .add-btn {
      display: block;
      width: 100%;
      background: #00bfff;
      padding: 12px;
      border: none;
      color: #001f3f;
      font-weight: bold;
      font-size: 16px;
      cursor: pointer;
      border-radius: 12px;
      transition: all 0.3s ease;
      margin-top: 10px;
    }
    .add-btn:hover {
      background: #0093cc;
    }
    .preview-gallery {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }
    .preview-item {
      border: 2px solid #00bfff;
      padding: 10px;
      border-radius: 15px;
      background-color: rgba(0, 0, 0, 0.4);
      position: relative;
      width: 150px;
      text-align: center;
      box-shadow: 0 0 10px #00bfff;
    }
    .preview-item img {
      max-width: 100%;
      border-radius: 10px;
    }
    .image-type-label {
      font-size: 14px;
      margin-top: 8px;
      color: #00bfff;
      font-weight: bold;
    }
    .remove-btn {
      position: absolute;
      top: 5px;
      right: 5px;
      background-color: red;
      color: white;
      border: none;
      border-radius: 50%;
      width: 25px;
      height: 25px;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <form method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label>Event Status</label>
      <select name="status" onchange="toggleFields(this.value)">
        <?php foreach ($statuses as $s): ?>
          <option value="<?= $s ?>" <?= $event['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Upcoming Fields -->
    <div id="upcoming-fields" style="display: none;">
      <?php
      $fields = [
        'title' => 'Event Title',
        'description' => 'Description',
        'date' => 'Event Date',
        'time' => 'Event Time',
        'venue' => 'Venue',
        'event_code' => 'Event Code',
        'event_rules' => 'Event Rules',
        'registration_fee' => 'Registration Fee'
      ];
      foreach ($fields as $key => $label): ?>
        <div class="form-group">
          <label><?= $label ?></label>
          <input type="<?= $key === 'date' ? 'date' : ($key === 'time' ? 'time' : 'text') ?>" name="<?= $key ?>" value="<?= htmlspecialchars($event[$key]) ?>">
        </div>
      <?php endforeach; ?>

      <div class="form-group">
        <label>Department</label>
        <select name="department">
          <?php foreach ($depts as $dept): ?>
            <option value="<?= $dept ?>" <?= $event['department'] === $dept ? 'selected' : '' ?>><?= $dept ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label>Event Type</label>
        <select name="event_type">
          <?php foreach ($types as $type): ?>
            <option value="<?= $type ?>" <?= $event['event_type'] === $type ? 'selected' : '' ?>><?= $type ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label>Event Category</label>
        <select name="event_category">
          <?php foreach ($cats as $cat): ?>
            <option value="<?= $cat ?>" <?= $event['event_category'] === $cat ? 'selected' : '' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label>Event Main Image</label>
        <input type="file" name="event_image" accept="image/*">
      </div>
    </div>

    <!-- Completed Upload Fields -->
    <div id="completed-fields" style="display: none;">
      <div class="form-block">
        <label for="image_type">Image Type</label>
        <select id="image_type">
          <?php foreach ($img_types as $type): ?>
            <option value="<?= $type ?>"><?= $type ?></option>
          <?php endforeach; ?>
        </select>

        <label for="image_input">Upload Image</label>
        <input type="file" id="image_input" accept="image/*">
        <button type="button" class="add-btn" onclick="addImage()">+ Add Image</button>
      </div>

      <div class="preview-gallery" id="preview_gallery"></div>
    </div>

    <div class="button-group">
      <button type="submit" class="button">Update Event</button>
      <a href="event_dashboard.php" class="button" style="text-align:center; line-height:40px;">Back to Dashboard</a>
    </div>
  </form>

<script>
function toggleFields(status) {
  document.getElementById('upcoming-fields').style.display = (status === 'upcoming') ? 'block' : 'none';
  document.getElementById('completed-fields').style.display = (status === 'completed') ? 'block' : 'none';
}
window.onload = () => {
  const selectedStatus = document.querySelector('select[name="status"]').value;
  toggleFields(selectedStatus);
};

function addImage() {
  const imageInput = document.getElementById('image_input');
  const imageType = document.getElementById('image_type').value;
  const previewGallery = document.getElementById('preview_gallery');

  if (imageInput.files.length === 0) return;

  const file = imageInput.files[0];
  const reader = new FileReader();

  reader.onload = function (e) {
    const previewItem = document.createElement('div');
    previewItem.classList.add('preview-item');

    const img = document.createElement('img');
    img.src = e.target.result;

    const hiddenTypeInput = document.createElement('input');
    hiddenTypeInput.type = 'hidden';
    hiddenTypeInput.name = 'image_types[]';
    hiddenTypeInput.value = imageType;

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.name = 'event_images[]';
    fileInput.style.display = 'none';

    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    fileInput.files = dataTransfer.files;

    const removeBtn = document.createElement('button');
    removeBtn.classList.add('remove-btn');
    removeBtn.innerText = '✖';
    removeBtn.onclick = () => previewGallery.removeChild(previewItem);

    const typeLabel = document.createElement('div');
    typeLabel.classList.add('image-type-label');
    typeLabel.innerText = imageType;

    previewItem.appendChild(removeBtn);
    previewItem.appendChild(img);
    previewItem.appendChild(typeLabel);
    previewItem.appendChild(hiddenTypeInput);
    previewItem.appendChild(fileInput);

    previewGallery.appendChild(previewItem);
    imageInput.value = '';
  };

  reader.readAsDataURL(file);
}
</script>
</body>
</html>
