<?php
include '../config/db.php';

// Fetch dropdown data
$departments = mysqli_query($conn, "SELECT DISTINCT department FROM events");
$event_types = mysqli_query($conn, "SELECT DISTINCT event_type FROM events");
$event_categories = mysqli_query($conn, "SELECT DISTINCT event_category FROM events");

if (isset($_POST['submit'])) {
    $event_code = $_POST['event_code'];
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $venue = $_POST['venue'];
    $registration_fee = $_POST['registration_fee'];
    $event_rules = $_POST['event_rules'];
    $description = $_POST['description'];

    $department = $_POST['department'] === 'Other' ? $_POST['department_other'] : $_POST['department'];
    $event_type = $_POST['event_type'] === 'Other' ? $_POST['event_type_other'] : $_POST['event_type'];
    $event_category = $_POST['event_category'] === 'Other' ? $_POST['event_category_other'] : $_POST['event_category'];

    // Handle Image Upload
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/';
        $file_name = basename($_FILES['image']['name']);
        $image_path = $upload_dir . time() . "_" . $file_name;
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);
    }

    $stmt = $conn->prepare("INSERT INTO events (event_code, title, date, time, venue, registration_fee, event_rules, description, department, event_type, event_category, event_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssss", $event_code, $event_name, $event_date, $event_time, $venue, $registration_fee, $event_rules, $description, $department, $event_type, $event_category, $image_path);
    $stmt->execute();

    echo "<script>alert('Event submitted successfully!'); location.href='../events/event_dashboard.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Add Event</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(160deg, #001f3f 0%, #000814 100%);
      color: #ffffff;
      overflow-x: hidden;
    }

    .form-container {
      max-width: 700px;
      margin: 50px auto;
      background: rgba(255, 255, 255, 0.05);
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 255, 255, 0.2);
      backdrop-filter: blur(10px);
      position: relative;
      z-index: 2;
    }

    .form-group {
      margin-bottom: 25px;
    }

    label {
      display: block;
      font-size: 1rem;
      color: #aad8ff;
      margin-bottom: 8px;
    }

    input[type="text"],
    input[type="date"],
    input[type="time"],
    input[type="file"],
    input[type="number"],
    textarea,
    select {
      width: 100%;
      background: transparent;
      border: none;
      border-bottom: 2px solid #aad8ff;
      color: #fff;
      font-size: 1rem;
      padding: 10px 5px;
      outline: none;
    }

    textarea {
      height: 80px;
      resize: vertical;
    }

    select {
      background-color: #002b5c;
      color: #ffffff;
      border: none;
      border-bottom: 2px solid #aad8ff;
      padding: 10px 5px;
      font-size: 1rem;
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      border-radius: 5px;
      transition: background-color 0.3s;
      background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%20xmlns%3D%22http://www.w3.org/2000/svg%22%3E%3Cpolygon%20points%3D%225%2C7%2010%2C12%2015%2C7%22%20fill%3D%22%23aad8ff%22/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 10px center;
      background-size: 12px;
      padding-right: 30px;
    }

    select:focus {
      outline: none;
      background-color: #003d7a;
    }

    input[type="submit"] {
      width: 100%;
      padding: 12px;
      background: #007BFF;
      border: none;
      color: white;
      border-radius: 25px;
      cursor: pointer;
      transition: 0.3s;
      font-weight: bold;
    }

    input[type="submit"]:hover {
      background: #0056b3;
    }

    .drag-drop-box {
      border: 2px dashed #00bfff;
      padding: 20px;
      text-align: center;
      border-radius: 10px;
      cursor: pointer;
      color: #00bfff;
    }

    #image-preview {
      margin-top: 10px;
      max-width: 100%;
      border-radius: 10px;
      display: none;
    }

    .bubble {
      position: fixed;
      background: rgba(173, 216, 230, 0.15);
      border-radius: 50%;
      pointer-events: auto;
      z-index: 0;
      transition: box-shadow 0.3s, transform 0.3s;
    }

    .bubble:hover,
    .bubble.paused {
      box-shadow: 0 0 15px 5px rgba(0, 255, 255, 0.8), 0 0 25px 10px rgba(0, 100, 255, 0.5);
      transform: scale(1.2);
      cursor: pointer;
    }
  </style>
</head>
<body>
<div class="form-container">
  <form method="POST" enctype="multipart/form-data">

    <!-- Image Upload First -->
    <div class="form-group">
      <label for="image">Upload Event Image</label>
      <div class="drag-drop-box" onclick="document.getElementById('image').click();" ondrop="handleDrop(event);" ondragover="event.preventDefault();">Click or Drag & Drop Image</div>
      <input type="file" name="image" id="image" style="display:none;" accept="image/*" onchange="previewImage(event)" />
      <img id="image-preview" />
    </div>

    <?php
      $reordered_fields = [
        'Event Name' => 'event_name',
        'Department' => 'department',
        'Description' => 'description',
        'Venue' => 'venue',
        'Event Date' => 'event_date',
        'Event Time' => 'event_time',
        'Event Type' => 'event_type',
        'Event Category' => 'event_category',
        'Event Rules' => 'event_rules',
        'Event Code' => 'event_code',
        'Registration Fee' => 'registration_fee'
      ];

      foreach ($reordered_fields as $label => $name) {
        echo "<div class='form-group'><label for='$name'>$label</label>";

        if ($name === 'event_type' || $name === 'event_category' || $name === 'department') {
          $options = ($name === 'event_type') ? $event_types : (($name === 'event_category') ? $event_categories : $departments);
          echo "<select name='$name' id='{$name}_select' required onchange='toggleOther(\"$name\")'>";
          echo "<option value='select' disabled selected>Please select option</option>";
          while ($row = mysqli_fetch_assoc($options)) {
            $val = htmlspecialchars($row[$name]);
            echo "<option value='$val'>$val</option>";
          }
          echo "<option value='Other'>Other</option></select>";
          echo "<input type='text' name='{$name}_other' id='{$name}_other' placeholder='Enter $label' style='display:none; margin-top:10px;' />";
        } elseif ($name === 'event_rules' || $name === 'description') {
          echo "<textarea name='$name' required></textarea>";
        } else {
          $type = ($name === 'event_date') ? 'date' : (($name === 'event_time') ? 'time' : (($name === 'registration_fee') ? 'number' : 'text'));
          echo "<input type='$type' name='$name' required />";
        }

        echo "</div>";
      }
    ?>

<div style="display: flex; gap: 15px; justify-content: center; margin-top: 20px;">
  <a href="event_dashboard.php" style="
      flex:1;
      text-align: center;
      padding: 12px;
      background: #6c757d;
      color: white;
      text-decoration: none;
      border-radius: 25px;
      font-weight: bold;
      display: inline-block;
      transition: background 0.3s;
  " onmouseover="this.style.background='#5a6268'" onmouseout="this.style.background='#6c757d'">
    Back to Dashboard
  </a>
  <input type="submit" name="submit" value="Submit Event" style="flex:1;" />

</div>
  </form>
</div>

<script>
  function toggleOther(field) {
    const sel = document.getElementById(field + "_select");
    const other = document.getElementById(field + "_other");
    other.style.display = sel.value === "Other" ? "block" : "none";
  }

  function previewImage(event) {
    const file = event.target.files[0];
    const preview = document.getElementById("image-preview");
    if (file) {
      preview.src = URL.createObjectURL(file);
      preview.style.display = "block";
    }
  }

  function handleDrop(e) {
    e.preventDefault();
    const fileInput = document.getElementById('image');
    fileInput.files = e.dataTransfer.files;
    previewImage({ target: fileInput });
  }

  // Bubbles Animation
  const numBubbles = 80;
  const bubbles = [];

  for (let i = 0; i < numBubbles; i++) {
    const bubble = document.createElement('div');
    bubble.classList.add('bubble');

    const size = Math.random() * 30 + 20;
    bubble.style.width = `${size}px`;
    bubble.style.height = `${size}px`;
    bubble.style.left = `${Math.random() * window.innerWidth}px`;
    bubble.style.top = `${Math.random() * window.innerHeight}px`;

    const speedX = (Math.random() - 0.5) * 2.5;
    const speedY = (Math.random() - 0.5) * 2.5;

    document.body.appendChild(bubble);

    bubbles.push({
      el: bubble,
      x: parseFloat(bubble.style.left),
      y: parseFloat(bubble.style.top),
      dx: speedX,
      dy: speedY,
      paused: false,
    });

    bubble.addEventListener("mouseenter", () => {
      bubble.classList.add('paused');
      bubbles[i].paused = true;
    });

    bubble.addEventListener("mouseleave", () => {
      bubble.classList.remove('paused');
      bubbles[i].paused = false;
    });
  }

  function animateBubbles() {
    bubbles.forEach((b) => {
      if (!b.paused) {
        b.x += b.dx;
        b.y += b.dy;

        if (b.x <= 0 || b.x + b.el.offsetWidth >= window.innerWidth) {
          b.dx *= -1;
        }
        if (b.y <= 0 || b.y + b.el.offsetHeight >= window.innerHeight) {
          b.dy *= -1;
        }

        b.el.style.left = `${b.x}px`;
        b.el.style.top = `${b.y}px`;
      }
    });

    requestAnimationFrame(animateBubbles);
  }

  animateBubbles();
</script>
</body>
</html>
