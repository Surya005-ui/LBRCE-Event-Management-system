<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

include '../config/db.php';
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM events WHERE faculty_id='$user_id'";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0d6efd, #05386b);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            text-align: center;
        }

        /* Header Section */
        .header {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px 30px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header h1 {
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: #ff4d4d;
            color: white;
            padding: 8px 16px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            border-radius: 5px;
            transition: 0.3s;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        /* Events Section */
        .events-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .event-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
            width: 300px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .event-card:hover {
            transform: translateY(-10px) scale(1.03);
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.4);
        }

        .event-title {
            font-size: 22px;
            font-weight: bold;
            color: #0d6efd;
            margin-bottom: 15px;
        }

        /* Buttons */
        .buttons {
            margin-top: 10px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .button {
            display: inline-block;
            background: #0d6efd;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .button:hover {
            background: #05386b;
            transform: scale(1.1);
        }

        /* Create Event Section */
        .create-event {
            margin-top: 30px;
        }

        .create-button {
            background: #198754;
            color: white;
            padding: 12px 25px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
            display: inline-block;
        }

        .create-button:hover {
            background: #146c43;
            transform: scale(1.1);
        }

        /* Enhanced Background Designs */
        .background-design {
    position: absolute;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(0,183,255,0.1) 100%);
    animation: floatWave 8s infinite ease-in-out;
    opacity: 0.8;
    z-index: 0;
    pointer-events: none;
}


.background-design:nth-child(1) {
    position: fixed;
    top: -60px;
    left: -60px;
    animation-delay: 0s;
    transform: scale(1);
}

.background-design:nth-child(2) {
    position: fixed;
    bottom: -40px;
    right: -60px;
    animation-delay: 2s;
    transform: scale(1.2);
}

.background-design:nth-child(3) {
    position: fixed;
    top: 20%;
    left: 80%;
    width: 160px;
    height: 160px;
    background: radial-gradient(circle, rgba(255,255,255,0.06) 0%, rgba(102,255,255,0.05) 100%);
    animation-delay: 4s;
    transform: scale(0.9);
}

/* Add more orbs if needed */
.background-design:nth-child(4) {
    position: fixed;
    top: 60%;
    left: 10%;
    width: 180px;
    height: 180px;
    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, rgba(0,153,255,0.06) 100%);
    animation-delay: 6s;
    transform: scale(1.1);
}

@keyframes floatWave {
    0% {
        transform: translate(0, 0) scale(1);
    }
    25% {
        transform: translate(40px, -30px) scale(1.1);
    }
    50% {
        transform: translate(-30px, 30px) scale(1.2);
    }
    75% {
        transform: translate(20px, -25px) scale(1.1);
    }
    100% {
        transform: translate(0, 0) scale(1);
    }
}


    </style>
</head>
<body>

<!-- Floating Background Designs -->
<div class="background-design"></div>
<div class="background-design"></div>
<div class="background-design"></div>
<div class="background-design"></div>


<div class="container">
    <div class="header">
        <h1>Faculty Dashboard</h1>
        <a href="../auth/logout.php"><button class="logout-btn">Log Out</button></a>
    </div>

    <?php if ($result->num_rows > 0) { ?>
        <div class="events-container">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="event-card">
                    <p class="event-title"><?= htmlspecialchars($row['title']) ?></p>
                    <div class="buttons">
                        <a href="edit_event.php?event_id=<?= $row['id'] ?>" class="button">Edit</a>
                        <a href="view_event_registrations.php?event_id=<?= $row['id'] ?>" class="button">View Registrations</a>
                    </div>
                </div>
            <?php } ?>
        </div>
        <div class="create-event">
            <p style="color: white; font-size: 18px;">Create More Events</p>
            <a href="add_event.php" class="create-button">Create an Event</a>
        </div>
    <?php } else { ?>
        <div class="create-event">
            <p style="color: white; font-size: 18px;">No events created.</p>
            <a href="add_event.php" class="create-button">Create an Event</a>
        </div>
    <?php } ?>
</div>

</body>
</html>
