<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

include '../config/db.php';

$event_id = $_GET['event_id'] ?? null;
if (!$event_id) {
    echo "Invalid Event ID!";
    exit();
}

// Fetch event details
$event_query = "SELECT title FROM events WHERE id='$event_id' AND faculty_id='{$_SESSION['user_id']}'";
$event_result = $conn->query($event_query);
if ($event_result->num_rows === 0) {
    echo "Event not found or unauthorized access!";
    exit();
}
$event = $event_result->fetch_assoc();

// Fetch registrations
$query = "SELECT * FROM registrations WHERE event_id='$event_id'";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Registrations - <?= htmlspecialchars($event['title']) ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            margin: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Registrations for <?= htmlspecialchars($event['title']) ?></h1>

    <?php if ($result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Team Name</th>
                <th>Leader Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Member 1</th>
                <th>Member 2</th>
                <th>Member 3</th>
                <th>Member 4</th>
                <th>Member 5</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($row['team_name']) ?></td>
                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                    <td><?= htmlspecialchars($row['student_email']) ?></td>
                    <td><?= htmlspecialchars($row['phone_number']) ?></td>
                    <td><?= htmlspecialchars($row['student1']) ?></td>
                    <td><?= htmlspecialchars($row['student2']) ?></td>
                    <td><?= htmlspecialchars($row['student3']) ?></td>
                    <td><?= htmlspecialchars($row['student4']) ?></td>
                    <td><?= htmlspecialchars($row['student5']) ?></td>
                    <td><a href="">Shortlist</a><br><a href="">Reject</a></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p>No Registrations Found.</p>
    <?php } ?>

    <a href="../events/event_dashboard.php" class="back-btn">Back to Dashboard</a>
</div>

</body>
</html>
