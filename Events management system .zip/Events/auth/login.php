<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    // Prevent SQL Injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            if ($remember) {
                setcookie("username", $username, time() + (86400 * 30), "/");
            } else {
                setcookie("username", "", time() - 3600, "/");
            }

            header('Location: ../events/event_dashboard.php');
            exit();
        } else {
            $error_message = 'Invalid password';
        }
    } else {
        $error_message = 'User not found';
    }
}

$saved_username = isset($_COOKIE['username']) ? $_COOKIE['username'] : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: url("../assets/images/lbrce.jpeg") no-repeat center center/cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login {
            background: rgba(44, 74, 140, 0.2);
            padding: 30px;
            border-radius: 10px;
            backdrop-filter: blur(500px);
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 320px;
        }

        h2 {
            color: #000;
            margin-bottom: 20px;
        }

        .input-container {
            position: relative;
            width: 100%;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
        }

        input[type="text"], input[type="password"] {
            background: rgba(255, 255, 255, 0.8);
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 18px;
            color: #333;
        }

        .remember-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 10px 0;
        }

        .remember-container label {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #212dcf;
            font-size: 14px;
            cursor: pointer;
        }

        .remember-container input[type="checkbox"] {
            width: 14px;
            height: 14px;
            cursor: pointer;
        }

        .forgot-password {
            color: green;
            text-decoration: none;
            font-size: 14px;
        }

        .forgot-password:hover {
            text-decoration: underline;
            color:red;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #0056b3;
        }

        .back-btn {
            margin-top: 10px;
            background: #dc3545;
        }

        .back-btn:hover {
            background: #a71d2a;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <div class="login">
        <h2>Login</h2>
        
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } ?>

        <form method="post">
            <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($saved_username); ?>" required>

            <div class="input-container">
                <input type="password" name="password" id="password" placeholder="Password" required>
                <span class="password-toggle" onclick="togglePassword()">👁️</span>
            </div>
            
            <div class="remember-container">
                <label>
                    <input type="checkbox" name="remember" <?php echo isset($_COOKIE['username']) ? 'checked' : ''; ?>> Remember Me
                </label>
                <a href="forgot_password.php" class="forgot-password">Forgot Password?</a>
            </div>

            <button type="submit">Login</button>
        </form>

        <a href="../index.php"><button class="back-btn">Back to Home</button></a>
    </div>

    <script>
        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var toggleIcon = document.querySelector(".password-toggle");
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.textContent = "🙈"; // Change to hidden eye emoji
            } else {
                passwordInput.type = "password";
                toggleIcon.textContent = "👁️"; // Change back to open eye
            }
        }
    </script>

</body>
</html>
