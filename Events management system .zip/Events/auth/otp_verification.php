<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '../config/db.php';
    $otp = $_POST['otp'];

    $query = "SELECT * FROM users WHERE id='{$_SESSION['user_id']}' AND otp='$otp'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $conn->query("UPDATE users SET is_verified=1 WHERE id='{$_SESSION['user_id']}'");
        header('Location: ../events/event_dashboard.php');
        exit();
    } else {
        echo 'Invalid OTP';
    }
}
?>
<form method="post">
    <input type="text" name="otp" placeholder="Enter OTP" required>
    <button type="submit">Verify</button>
</form>