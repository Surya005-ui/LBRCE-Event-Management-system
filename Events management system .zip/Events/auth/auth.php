<?php
include '../config/db.php';
    $username = "naveen";
    $password = "banti1298";

    $hash_password = password_hash( $password, PASSWORD_DEFAULT);

    echo $hash_password;

    if (password_verify($password, $hash_password)) {
        echo "<br>".$password;
    } 
    

    // $query = "INSERT INTO `users` (`id`, `username`, `password`, `email`, `otp`, `is_verified`) VALUES (NULL, 'loki1', $hash_password, 'loki1@gmail.com', NULL, '0');";
    // $result = $conn->query($query);
?>