<?php include 'config/db.php';
$updateQuery = "UPDATE events SET status = 'Completed' WHERE date < CURDATE() AND status != 'Completed'";

if (mysqli_query($conn, $updateQuery)) {
    echo "<script>console.log('Status updated successfully!');</script>";
} else {
    echo "<script>console.log('Error updating status: " . mysqli_error($conn) . "');</script>";
}

?>
<?php include 'includes/header.php'; ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
body { font-family: 'Poppins', sans-serif; background: #0a192f; margin: 0; padding: 0; color: #333; overflow-x: hidden; }
.container { width: 90%; margin: auto; }
h2 { text-align: center; color: #01579b; padding: 20px; text-transform: uppercase; position: relative; }
h2::after { content: ''; width: 100px; height: 3px; background: #0288d1; position: absolute; bottom: 5px; left: 50%; transform: translateX(-50%); }
h2 span { color: #fff; }
.hero { position: relative; height: 400px; overflow: hidden; margin-top: 20px; }
.slider { display: flex; transition: transform 1s ease-in-out; }
.slide { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; transition: opacity 1s; z-index: 0; }
.slide.active { opacity: 1; z-index: 1; }
.slide img { width: 100%; height: 100%; object-fit: cover; display: block; filter: brightness(60%); }
.gradient-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom right, rgba(0,0,0,0.5), rgba(10,25,47,0.8)); z-index: 1; }
.slide-content { position: absolute; z-index: 2; bottom: 10%; left: 5%; color: #fff; background: rgba(0,0,0,0.6); padding: 15px; border-radius: 8px; max-width: 90%; animation: fadeInUp 1s; }
.slide-content h2 { margin-bottom: 10px; }
.slide-content ul { padding-left: 20px; }
.slide-content button { background: #0288d1; border: none; padding: 10px 15px; margin-right: 10px; border-radius: 5px; color: #fff; cursor: pointer; }
.slide-content button:hover { background: #01579b; }
@keyframes fadeInUp { 0% { opacity: 0; transform: translateY(20px); } 100% { opacity: 1; transform: translateY(0); } }
.nav-arrow { position: absolute; top: 50%; transform: translateY(-50%); font-size: 2rem; color: #fff; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 50%; cursor: pointer; z-index: 3; }
.nav-arrow:hover { background: rgba(0,0,0,0.6); }
.arrow-left { left: 15px; } .arrow-right { right: 15px; }
.dots { position: absolute; bottom: 15px; left: 50%; transform: translateX(-50%); z-index: 3; display: flex; gap: 8px; }
.dot { width: 12px; height: 12px; background: rgba(255,255,255,0.6); border-radius: 50%; cursor: pointer; }
.dot.active { background: #0288d1; }
.search-bar { text-align: center; margin: 20px; }
.search-bar input { width: 50%; padding: 10px; border-radius: 5px; border: 2px solid #0277bd; transition: 0.3s; }
.search-bar input:focus { outline: none; border-color: #01579b; box-shadow: 0 0 10px #0277bd; }
.event-list { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; }
.card { width: 300px; background: white; border-radius: 10px; box-shadow: 4px 4px 20px rgba(0,0,0,0.2); overflow: hidden; transition: 0.3s; position: relative; }
.card:hover { transform: translateY(-10px) rotate(2deg); box-shadow: 6px 6px 20px rgba(0,0,0,0.3); }
.card::before { content: ''; position: absolute; inset: 0; background: rgba(2,136,209,0.1); z-index: -1; transform: scaleX(0); transition: 0.5s; }
.card:hover::before { transform: scaleX(1); }
.card img { width: 100%; height: 180px; object-fit: cover; }
.card-content { padding: 15px; text-align: center; }
.card-content h3 { color: #0277bd; }
.card-content button { background: #0288d1; color: white; border: none; padding: 10px; width: 100%; border-radius: 5px; cursor: pointer; transition: 0.3s; }
.card-content button:hover { background: #01579b; transform: scale(1.1); }
.lbrceinfosections-wrapper { padding: 80px 20px; background: linear-gradient(to bottom, #0a192f, #102841); text-align: center; }
.lbrceinfosections-title { font-size: 3rem; margin-bottom: 15px; color: #e0f0ff; text-shadow: 0 2px 10px rgba(0,0,0,0.3); }
.lbrceinfosections-description { max-width: 850px; margin: 0 auto 50px; font-size: 1.1rem; color: #a0bcd5; }
.lbrceinfosections-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; }
.lbrceinfosections-card { background: rgba(255,255,255,0.05); border-radius: 18px; overflow: hidden; box-shadow: 0 8px 20px rgba(0,0,0,0.3); backdrop-filter: blur(12px); transition: transform 0.4s; border: 1px solid rgba(255,255,255,0.1); }
.lbrceinfosections-card:hover { transform: translateY(-10px); }
.lbrceinfosections-card img { width: 100%; height: 180px; object-fit: cover; filter: brightness(0.8); transition: transform 0.4s; }
.lbrceinfosections-card-content { padding: 20px; text-align: left; background: rgba(255,255,255,0.1); }
.lbrceinfosections-card-content h3 { margin: 0; color: #fff; font-size: 1.4rem; }
.lbrceinfosections-card-content p { color: #c1d9f0; font-size: 0.95rem; }
.modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 9999; }
.modal-content { background: #0a192f; width: 90%; max-width: 90%; padding: 20px 60px; border-radius: 10px; max-height: 90vh; overflow-y: auto; position: relative; animation: fadeIn 0.4s ease-in-out; }
.modal-content { scrollbar-width: thin; scrollbar-color: #1eb2ff #0a192f; }
.modal-content::-webkit-scrollbar { width: 8px; }
.modal-content::-webkit-scrollbar-track { background: #0a192f; border-radius: 10px; }
.modal-content::-webkit-scrollbar-thumb { background-color: #1eb2ff; border-radius: 10px; border: 2px solid #0a192f; }
.close-modal { position: absolute; top: 10px; right: 15px; font-size: 48px; font-weight: bold; color: #fff; cursor: pointer; }
.close-modal:hover { color: #ff0000; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
</style>

<div class="container">
<section class="hero">
<div class="slider" id="slider">
<?php
$slides = [];
$res = mysqli_query($conn, "SELECT e1.* FROM events e1 INNER JOIN (SELECT department, MAX(date) AS max_date FROM events WHERE event_image IS NOT NULL AND event_image != '' GROUP BY department) e2 ON e1.department = e2.department AND e1.date = e2.max_date WHERE e1.event_image IS NOT NULL AND e1.event_image != '' ORDER BY e1.department ASC");
while ($event = mysqli_fetch_assoc($res)) $slides[] = $event;
if (count($slides)) foreach ($slides as $i => $event)
echo "<div class='slide".($i === 0 ? " active" : "")."'><img src='uploads/".htmlspecialchars($event['event_image'])."'><div class='gradient-overlay'></div><div class='slide-content'><h2><span>".htmlspecialchars($event['department'])." Dept</span><br>".htmlspecialchars($event['title'])."</h2><ul><li><strong>📅 Date:</strong> ".htmlspecialchars($event['date'])."</li><li><strong>🏷️ Type:</strong> ".htmlspecialchars($event['event_type'])."</li><li><strong>📂 Category:</strong> ".htmlspecialchars($event['event_category'])."</li></ul><div><button onclick='openModal({$event['id']})'>View Details</button><a href='student/register_event.php?event_id={$event['id']}'><button>Register</button></a></div></div></div>";
else echo "<div class='slide active'><div class='slide-content'><h3>No Recent Events Found</h3></div></div>";
?>
</div>
<div class="nav-arrow arrow-left" onclick="changeSlide(-1)">❮</div>
<div class="nav-arrow arrow-right" onclick="changeSlide(1)">❯</div>
<div class="dots" id="dots"></div>
</section>

<div id="eventModal" class="modal-overlay" style="display:none;">
  <div class="modal-content">
    <span class="close-modal" onclick="closeModal()">×</span>
    <div id="modalBody">Loading...</div>
  </div>
</div>

<section class="lbrceinfosections-wrapper">
  <h2 class="lbrceinfosections-title">LBRCE Events & Culture</h2>
  <p class="lbrceinfosections-description">LBRCE hosts diverse technical, cultural, and career events that fuel innovation and collaboration.</p>
  <div class="lbrceinfosections-cards">
    <?php
$types = [["Hackathons", "Collaborative coding events where developers solve challenges, innovate, and build prototypes under deadlines.", "https://i.pinimg.com/736x/f1/37/b1/f137b1914b1b9358e9ff9c0a76b852f3.jpg"], ["Workshops", "Interactive learning sessions offering hands-on experience to gain practical skills in specific domains or technologies.", "https://i.pinimg.com/736x/82/7b/02/827b0246f4a0094b6798afeb02a64f0e.jpg"], ["Bootcamps", "Intensive, short-term programs designed to teach participants in-demand skills through practical, immersive training modules.", "https://i.pinimg.com/736x/5d/4d/8f/5d4d8fdd59f50fc4b5e97528f08bf26c.jpg"], ["Tech Fests", "Large-scale events celebrating technology through exhibitions, contests, guest talks, and student-led innovation showcases.", "https://i.pinimg.com/736x/51/df/b0/51dfb0e3c28c58145d4a015f26040426.jpg"], ["Seminars", "Academic or professional gatherings where experts present ideas, research, and insights on specialized topics.", "https://i.pinimg.com/736x/cd/56/fa/cd56fa0110ce549283ab2cbffdfd5396.jpg"], ["Cultural Fests", "Lively events filled with music, dance, drama, and art showcasing campus creativity and diverse traditions.", "https://i.pinimg.com/736x/00/a0/cf/00a0cf0219982857c0a634c276aef836.jpg"], ["Webinars", "Virtual seminars conducted online, providing global access to expert insights and interactive learning experiences.", "https://i.pinimg.com/736x/36/1f/1b/361f1b5aaa63633047a8afab77c24dc9.jpg"], ["Career Fairs", "Events connecting students with companies offering internships, job opportunities, and career development resources.", "https://i.pinimg.com/736x/90/b9/d5/90b9d57299c253a7196aad2e94a4ed95.jpg"], ["Guest Lectures", "Knowledge-rich sessions delivered by renowned experts sharing experiences, ideas, and industry or academic insights.", "https://i.pinimg.com/736x/57/30/80/573080aa4d11bf230afafa3da2eaa6a1.jpg"]];
  foreach ($types as [$t, $d, $i]) echo "<div class='lbrceinfosections-card'><img src='$i'><div class='lbrceinfosections-card-content'><h3>$t</h3><p>$d</p></div></div>";
    ?>
  </div>
</section>

<div class="search-bar"><input type="text" id="search" placeholder="Search events..." onkeyup="filterEvents()"></div>
<h2>Upcoming Events</h2>
<div class="event-list" id="eventList">
<?php
$upcoming = mysqli_query($conn, "SELECT * FROM events WHERE date >= CURDATE() ORDER BY date ASC");
if (mysqli_num_rows($upcoming) > 0)
while ($e = mysqli_fetch_assoc($upcoming)) echo "<div class='card'><img src='uploads/".htmlspecialchars($e['event_image'])."'><div class='card-content'><h3>".htmlspecialchars($e['title'])."</h3><button onclick='registerEvent(".$e['id'].")'>Register</button></div></div>";
else echo "<p class='no-events' style='text-align:center; width:100%'>No upcoming events.</p>";
?>
</div>
</div>

<script>
let currentSlide = 0, slides = document.querySelectorAll(".slide"), dotsContainer = document.getElementById("dots");
function showSlide(i) { slides.forEach((s, idx) => { s.classList.toggle("active", idx === i); dotsContainer.children[idx]?.classList.toggle("active", idx === i); }); }
function changeSlide(n) { currentSlide = (currentSlide + n + slides.length) % slides.length; showSlide(currentSlide); }
function createDots() { slides.forEach((_, i) => { let d = document.createElement("div"); d.className = "dot" + (i === 0 ? " active" : ""); d.onclick = () => showSlide(currentSlide = i); dotsContainer.appendChild(d); }); }
createDots(); setInterval(() => changeSlide(1), 4000);
function registerEvent(id) { window.location.href = `student/register_event.php?event_id=${id}`; }
function filterEvents() {
  let input = document.getElementById("search").value.toLowerCase(), cards = document.querySelectorAll(".card"), match = 0;
  cards.forEach(c => { let t = c.querySelector("h3").innerText.toLowerCase(); c.style.display = t.includes(input) ? (match++, "block") : "none"; });
  let msg = document.querySelector(".no-events") || Object.assign(document.createElement("p"), { className: "no-events", style: "text-align:center; width:100%", textContent: "No events found." });
  document.getElementById("eventList").appendChild(msg);
  msg.style.display = match ? "none" : "block";
}
function openModal(id) {
  document.getElementById('eventModal').style.display = 'flex';
  document.getElementById('modalBody').innerHTML = 'Loading...';
  fetch(`student/event_details.php?event_id=${id}`).then(res => res.text()).then(data => document.getElementById('modalBody').innerHTML = data).catch(() => document.getElementById('modalBody').innerHTML = "<p>Failed to load event details.</p>");
}
function closeModal() { document.getElementById('eventModal').style.display = 'none'; }
window.onclick = function(e) { if (e.target == document.getElementById('eventModal')) closeModal(); }
</script>

<?php include 'includes/footer.php'; ?>
